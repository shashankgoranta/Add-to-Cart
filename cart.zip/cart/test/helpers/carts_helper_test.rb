require 'test_helper'

class CartsHelperTest < ActionView::TestCase
end
